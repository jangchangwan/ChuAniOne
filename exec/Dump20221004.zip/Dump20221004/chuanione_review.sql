-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: j7e104.p.ssafy.io    Database: chuanione
-- ------------------------------------------------------
-- Server version	5.7.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `review`
--

DROP TABLE IF EXISTS `review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `review` (
  `review_id` int(11) NOT NULL AUTO_INCREMENT,
  `content` varchar(1000) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `rating` double DEFAULT NULL,
  `animation_id` int(11) NOT NULL,
  `member_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`review_id`),
  KEY `member_id` (`member_id`),
  CONSTRAINT `review_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `member` (`member_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review`
--

LOCK TABLES `review` WRITE;
/*!40000 ALTER TABLE `review` DISABLE KEYS */;
INSERT INTO `review` VALUES (10,'주술회전 진짜 재밌숨 ㅜㅜ \n두번 봐요 세번보ㅓ요','2022-10-02 20:41:40',5,39986,2),(19,'리무르 템페스토 진짜 목소리 개하찮지만 귀엽다. 세계관 일짱','2022-10-02 16:31:46',5,38912,5),(21,'진짜 캐재밋음 대체 장르가 먼지 몰겟는데 다 잇음 긴토키 개기엽 글고 패러디들도 걍 ㅜ ㅋㅋ 어이없음 제작자 실화냐','2022-10-02 19:41:02',5,16075,5),(24,'아냐상노 와쿠와쿠와 혼또니 카와이이데스\n솔직히 스패는 만화보다 애니가 더 잼남요\n이유: 아냐 목소리가 다 살렷음','2022-10-02 20:14:18',5,40815,5),(25,'작화가 진짜 개미쳤음 실화냐 나 보고 깜짝 놀랐음 미친 거 아냐 진짜? 여기 내 원픽 네즈코임','2022-10-02 19:37:11',5,40562,5),(26,'도리벤 파트 1은 그냥 오프닝이고 사실상 파트 2도 오프닝임.. 진짜 스토리는 그 이후라고요..!! 타케밋치 너는 그만 좀 울어라 진짜 울때마다 패고 싶음. 도쿄만지회 너네 다 사랑해 나는 너네가 채고야 얘들아 누가 너네 그림체로 욕해도 울지마 귀 막아 카즈토라 개멋있음 사실 마이키도 멋있고 범천 마이키 언제 나와 진짜 미치겟네 근데 다 됏고 신이치로 ㅜ ㅜ 너가 짱이다 이거 캐존잼이라 만화책 재탕 캐만이함 근데??? 중2 중3 ㅋㅋ 이라 생각하면 걍 욱김. 다들 나이 잊고 보세요 .. ....... 그치만 ㅡ ㅡ 애니는 원래 캐릭터 때문에 보는 거잔 아 요 ㅡ ㅡ','2022-10-02 20:01:01',5,40260,5),(27,'진짜 이거 남장 이런거 유행햇을때라서 하 나 미치겐네 이거도 잼남 ㅜ ㅜ 어릴 땐 다들 좋앗는데.. 그 중 원픽은 사실 유재석','2022-10-02 20:04:03',5,15516,5),(28,'진짜 바지랑 치후유 때문에 내 심장 다 뜯겨 나갓다. 글고 카즈토라 진짜 개또라이 정신 나갓지만.. 그래도.. 용서해줄게 ㅜ ㅜ 진짜 이제 시작이라고요 1!!!!! 다들 도리벤 하세요 개띵작 스토리는 사실 뻔하지만(사실 만화가 다 그렇잔 아 요 ? ㅡㅡ 다 거기서 거기임) 도리벤이 사랑받는 이유는 캐릭터 때문임 하나하나가 다 매력이 있고 악역이건 아니건 ㅜ 미치겟음 얘네가 진짜 가오에 죽고 가오에 사는 애들임','2022-10-02 20:05:58',5,40394,5),(29,'나 진짜 이거 기대하고 일단 눌럿다가 7화에서 하차했음 나는 진짜 소제목도 ~~하고 말았다.. 일케 되어 있어서 머야 혼또 재밋을거같잔아?? 하고 기대햇는데 아녓음 걍 오글거림 그림체도 애매하고 남주 보고 내 가슴이 안뛰어요','2022-10-02 20:07:27',2,39745,5),(30,'젠이 진짜 넘 잘생겼음 누가봐도 왕자님이잔아 미치겐네 말도 예쁘게 해 ㅜ ㅜ 오글거리지만? 얼굴이 다임','2022-10-02 22:19:24',5,25009,5),(31,'이런게 있었는줄 지금 알았다니 ㅠㅠ\n지금이라도 봐서 다행이네요','2022-10-03 14:25:18',4,39986,4),(32,'사실 만화가 명작이라기 보단 유포터블이 레전드다 라는게 더 옳음\n사실 만화의 전개, 설정, 클리셰는 솔직히 좀 뻔함\n사실 주인공이 개쩌는 사람이랑 연관이 있다\n색 변하는 칼, 오니\n근데 유포터블이 작화랑 연출을 지리게 함','2022-10-03 14:25:49',3,39431,4),(33,'코난은 솔직히\n완결은 보고 싶지만, 완결나면 허전할뜻한 작품','2022-10-03 14:26:15',4,40188,4),(34,'제작진이랑 원작가가 병맛배틀하는 만화','2022-10-03 14:26:46',3,16075,4),(35,'더빙판 아냐도 우리를 와쿠와쿠 하게 할 수 있을까?!?!??!\n\n아니 아냐가 TV트는거 이상한 짤들 많아서 뭔가 원본이 오히려 위화감이 느껴져ㅋㅋㅋㅋㅋㅋㅋ\n더빙판 아냐....카와이!!!!\n근데 로이드가 뭔가 좀 국어책 읽는듯이 읽는 느낌나서 살짝 아쉽당...ㅜㅜ\n(근데 엔딩 가사 어디갔오...?)','2022-10-03 14:27:25',3,40815,4),(36,'이거 1화보다가 잠들엇어요 ','2022-10-03 17:35:31',1,16075,1),(37,'머리 나는 자르기 전이 더 조아 밋 친 ㅜ ㅣ진짜 기엽어','2022-10-03 18:16:12',5,40157,5),(38,'나 진짜 나나미 부러워서 미 치 겐네 나 이거 보러 만화카페 겁나 갓음.. \n토모에가 진짜 나는 채고야 근데 까마귀는 별로 생긴거 내 스 탈 아님 요','2022-10-03 18:35:30',5,23078,5),(39,'ㅁㅊ 나 진짜 연화 미치겐네 신아가 젤 잘생겼고 옆에 아오도 ㅜ ㅜ 귀여워 나도 용 데리고 다닐래\n그치만 내 원픽은 누가 뭐라고 해도 학임 ㅜ ㅜ 학쿤.. . .!!!!! ','2022-10-03 18:36:04',5,24470,5),(40,'나 이거 영화로도 보고 애니로도 봣는데 역시 애니가 더 심장을 뛰게 했음..!!! 너무 좋다','2022-10-03 18:36:49',5,23950,5),(41,'요시다 하루 진짜 ㅜ 생긴거 내스탈 역시 남캐는 까만 머리가 ㅡ ㅡ 기본이죠 !!!! 하루쿤 ㅜ ㅜ 채고야 나도 너랑 같이 크리스마스 보내고 싶어 최고다','2022-10-03 18:37:53',5,23313,5),(52,'슬라임 ㄷ ㄷ','2022-10-04 10:19:56',4.5,38912,21),(53,'제목때문에 거릅니다','2022-10-04 15:25:27',3,38921,26);
/*!40000 ALTER TABLE `review` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-04 19:22:53
