-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: j7e104.p.ssafy.io    Database: chuanione
-- ------------------------------------------------------
-- Server version	5.7.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `memorize_voca`
--

DROP TABLE IF EXISTS `memorize_voca`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `memorize_voca` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL,
  `voca_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `member_id` (`member_id`),
  KEY `voca_id` (`voca_id`),
  CONSTRAINT `memorize_voca_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `member` (`member_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `memorize_voca_ibfk_2` FOREIGN KEY (`voca_id`) REFERENCES `bigvoca` (`voca_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=96 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `memorize_voca`
--

LOCK TABLES `memorize_voca` WRITE;
/*!40000 ALTER TABLE `memorize_voca` DISABLE KEYS */;
INSERT INTO `memorize_voca` VALUES (6,4,8),(9,4,13),(13,4,8),(14,4,13),(15,4,13),(16,4,13),(18,2,8),(20,2,12),(21,2,15),(22,2,9),(23,2,13),(24,2,16),(25,2,18),(26,2,10),(27,2,14),(28,2,17),(29,2,19),(30,4,14),(31,4,15),(32,4,16),(33,4,19),(38,5,8),(39,5,31),(42,5,16),(44,5,41),(47,5,39),(48,5,43),(49,5,992),(50,5,15),(51,5,44),(53,5,45),(80,21,8),(81,21,9),(82,21,10),(83,21,11),(84,21,12),(85,21,13),(86,21,14),(87,4,9),(88,2,20),(89,2,22),(90,2,21),(91,2,11),(92,2,29),(93,4,12),(94,4,17),(95,21,15);
/*!40000 ALTER TABLE `memorize_voca` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-04 19:22:52
