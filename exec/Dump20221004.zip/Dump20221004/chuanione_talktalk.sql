-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: j7e104.p.ssafy.io    Database: chuanione
-- ------------------------------------------------------
-- Server version	5.7.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `talktalk`
--

DROP TABLE IF EXISTS `talktalk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `talktalk` (
  `talktalk_id` int(11) NOT NULL AUTO_INCREMENT,
  `content` varchar(1000) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `animation_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  PRIMARY KEY (`talktalk_id`),
  KEY `member_id` (`member_id`),
  CONSTRAINT `talktalk_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `member` (`member_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `talktalk`
--

LOCK TABLES `talktalk` WRITE;
/*!40000 ALTER TABLE `talktalk` DISABLE KEYS */;
INSERT INTO `talktalk` VALUES (82,'다들 애니 오타쿠면서 왜 상하를 나누지? ㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋ','','2022-10-04 10:15:23',40825,1),(83,'이거 재밌음?','','2022-10-04 10:17:07',39431,2),(84,'인생은 날씨와 같아 맑은 날도 있고, 눈이 오는 날도 있는 거야','','2022-10-04 10:17:40',39431,4),(85,'힘들더라도, 앞으로 나아가는 수밖에 없어요','','2022-10-04 10:17:51',39431,4),(86,'똑바로 앞을 쳐다봐라!! 자신을 단련시켜라!! \n힘내라, 탄지로!! 난 지금껏 잘해왔어!! \n난 할 수 있는 놈이다!! 오늘도, 앞으로도! 설령 부러졌다 해도!! 내가 굴하는 일은 절대로 없어!!','','2022-10-04 10:18:16',39431,4),(87,'주술회전 첫번째인김에 오늘은 주술회전 봐야지','','2022-10-04 10:18:55',39986,2),(89,'다이죠-부 오레 사이쿄-다까라','','2022-10-04 10:19:44',39986,4),(90,'탄지로오오오오오오오!!!!!!!!!!!','','2022-10-04 10:20:55',39431,21);
/*!40000 ALTER TABLE `talktalk` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-04 19:22:50
