-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: j7e104.p.ssafy.io    Database: chuanione
-- ------------------------------------------------------
-- Server version	5.7.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `chat`
--

DROP TABLE IF EXISTS `chat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat` (
  `chat_id` int(11) NOT NULL AUTO_INCREMENT,
  `message` varchar(255) DEFAULT NULL,
  `send_date` datetime DEFAULT NULL,
  `member_id` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  PRIMARY KEY (`chat_id`),
  KEY `member_id` (`member_id`),
  CONSTRAINT `chat_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `member` (`member_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=648 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat`
--

LOCK TABLES `chat` WRITE;
/*!40000 ALTER TABLE `chat` DISABLE KEYS */;
INSERT INTO `chat` VALUES (590,'사천성뜰사람','2022-10-04 10:21:58',1,10),(591,'사천성 !','2022-10-04 10:21:59',21,10),(592,'ㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋ','2022-10-04 10:22:01',1,10),(593,'ㄱ ?','2022-10-04 10:22:02',21,10),(594,'ㅋㅋㅋㅋㅋㅋㅋ','2022-10-04 10:22:02',1,10),(595,'저요 !','2022-10-04 10:22:03',2,10),(596,'ㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋ','2022-10-04 10:22:04',1,10),(597,'ㅋㅋㅋㅋㅋ','2022-10-04 10:22:05',1,10),(598,'간바레~','2022-10-04 10:22:06',4,11),(599,'ㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋ','2022-10-04 10:22:07',21,10),(600,'이방뭔데','2022-10-04 10:22:08',21,10),(601,'ㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋ','2022-10-04 10:22:08',2,10),(602,'ㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋ','2022-10-04 10:22:13',21,10),(604,'맘슽터치','2022-10-04 10:22:19',2,10),(605,'맘스터치 누구야','2022-10-04 10:22:23',2,10),(606,'귀칼노잼 인정합니다','2022-10-04 10:22:26',1,11),(607,'채팅완전잘되죠? ','2022-10-04 10:22:30',1,11),(610,'오','2022-10-04 10:22:34',5,11),(611,'장난아님','2022-10-04 10:22:37',1,11),(612,'이제 잘만 되는군요','2022-10-04 10:22:38',5,11),(613,'나는 뜨는데','2022-10-04 10:22:40',2,11),(614,'승현천재 ','2022-10-04 10:22:41',1,11),(615,'ㅎㅎㅎㅎ','2022-10-04 10:22:41',2,11),(616,'후후','2022-10-04 10:22:42',2,11),(617,'잘되지?','2022-10-04 10:22:44',2,11),(618,'어','2022-10-04 10:22:46',4,11),(619,'안돼?','2022-10-04 10:22:47',2,11),(620,'아주 맘에 들어요','2022-10-04 10:22:47',5,11),(621,'뭐야','2022-10-04 10:22:50',2,11),(622,'뭐가 이상해','2022-10-04 10:22:51',2,11),(623,'여기 동운이없나?','2022-10-04 10:22:51',4,11),(624,'어? 금지 ','2022-10-04 10:22:52',1,11),(626,'동운이 바보','2022-10-04 10:22:54',4,11),(627,'ㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋ','2022-10-04 10:22:55',1,11),(628,'동운이 멍청이','2022-10-04 10:22:57',4,11),(629,'ㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋ','2022-10-04 10:23:06',2,11),(630,'늘려드릴까여?','2022-10-04 10:23:10',2,11),(631,'ㅎㅎ','2022-10-04 10:23:12',2,11),(632,'수고링 동운~','2022-10-04 10:23:15',2,11),(633,'늘리지마','2022-10-04 10:23:16',4,11),(634,'안대','2022-10-04 10:23:17',4,11),(635,'아 이거 봐야하는데 ','2022-10-04 10:23:38',1,12),(636,'우리 늘리지말자','2022-10-04 10:23:40',2,11),(637,'지금 잘될때','2022-10-04 10:23:43',2,11),(638,'ㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋ','2022-10-04 10:23:44',1,11),(640,'멈춰야해','2022-10-04 10:23:45',2,11),(642,'ㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋ','2022-10-04 10:23:48',2,11),(643,'늘리면안대','2022-10-04 10:23:54',4,11),(644,'ㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋ','2022-10-04 10:23:56',1,11),(645,'ㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋ','2022-10-04 10:23:58',2,11),(646,'너무 웃기','2022-10-04 10:24:00',2,11),(647,'김','2022-10-04 10:24:01',2,11);
/*!40000 ALTER TABLE `chat` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-04 19:22:48
