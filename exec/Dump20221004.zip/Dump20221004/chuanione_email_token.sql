-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: j7e104.p.ssafy.io    Database: chuanione
-- ------------------------------------------------------
-- Server version	5.7.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `email_token`
--

DROP TABLE IF EXISTS `email_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_token` (
  `email_token_id` int(11) NOT NULL AUTO_INCREMENT,
  `expiration_date` datetime DEFAULT NULL,
  `expired` tinyint(1) DEFAULT NULL,
  `member_id` int(11) DEFAULT NULL,
  `id` varchar(36) NOT NULL,
  PRIMARY KEY (`email_token_id`),
  KEY `email_token_ibfk_1` (`member_id`),
  CONSTRAINT `email_token_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `member` (`member_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_token`
--

LOCK TABLES `email_token` WRITE;
/*!40000 ALTER TABLE `email_token` DISABLE KEYS */;
INSERT INTO `email_token` VALUES (25,'2022-09-26 17:41:09',1,1,'8881309e-dc93-4891-8707-bd89bc6b49be'),(26,'2022-09-26 23:27:34',1,2,'2c2ae5a3-18e2-4471-a90b-76cb199c80b3'),(30,'2022-09-27 11:49:06',1,4,'98321ee0-e230-42ba-b37c-e11e91477507'),(31,'2022-09-27 15:19:30',0,5,'cc1628ea-93ce-4a46-bf75-684c383f4177'),(33,'2022-09-29 23:23:40',1,7,'0d241a2b-b150-47e6-b050-3591b3639c47'),(37,'2022-09-30 14:49:28',0,18,'bfef3c74-2278-43ff-88f2-b741e5b3e157'),(40,'2022-10-02 16:34:25',1,21,'0c70b3f5-e1aa-4705-9274-568910e263e8'),(41,'2022-10-02 17:14:35',0,22,'d5a0dadc-0df3-42bc-a847-68cc83dfc966'),(43,'2022-10-04 04:21:15',0,24,'4bb0adc6-e32d-4f07-a89c-9084eab3db8c'),(44,'2022-10-04 04:22:30',0,25,'6e286438-8681-471d-8c35-db698d1b3697'),(45,'2022-10-04 15:29:07',1,26,'8f18e69a-0a76-4c21-9faf-2d6bc59bb6d0');
/*!40000 ALTER TABLE `email_token` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-04 19:22:47
