-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: j7e104.p.ssafy.io    Database: chuanione
-- ------------------------------------------------------
-- Server version	5.7.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
  `member_id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `nickname` varchar(20) DEFAULT NULL,
  `profile` varchar(255) DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `birthday` varchar(50) DEFAULT NULL,
  `introduction` varchar(200) DEFAULT NULL,
  `role` varchar(20) DEFAULT NULL,
  `token` varchar(255) DEFAULT NULL,
  `verified` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES (1,'qkrdbwn98@naver.com','$2a$10$.mSVCoS6vKx56jlch70wwuQw2NAeK/E8WQpGUic0ikPcckRoKiUm.','유주',NULL,'FEMALE','2022-10-01','오소이!','ROLE_USER','eyJhbGciOiJIUzUxMiJ9.eyJleHAiOjE2NjU0NTA4ODZ9.pO7a_MBzW47hYhU_J62eIQNRvDsjjSPl3hV4wo1eXBsQBEDgFpB5BPXu2onIDmNIMBGaqIM1tapBwtv-tyKfVg',1),(2,'window8397@naver.com','$2a$10$.39rtH/iiSKs7A9OVzotle8as6bxck2rhZkKrLdgThZC2Y55zZBau','푸푸언니','','FEMALE','1999-03-02','로맨스 덕후입니다만 후후','ROLE_USER','eyJhbGciOiJIUzUxMiJ9.eyJleHAiOjE2NjU0NTA3NjZ9.qtl9Xaxs-siIc6oyh5y2K6cAkqreBEPKxq0L-Pu-oWWmdkSYvduei18Y74MSGAODvtHEwkfDdOL5Sj8JoxugvQ',1),(4,'changwan327@naver.com','$2a$10$Xil144wfnOF/PaNbheFFB.a9pdnETPQSHOprD8XpbJQosYXHgME/q','와니','','MALE','1993-10-07','안녕하세요, 잘부탁드립니다 아리가또','ROLE_USER','eyJhbGciOiJIUzUxMiJ9.eyJleHAiOjE2NjU0NzQwNjJ9.E2V1sWpoX78dgL7P-yOio6Uw6ds9FSc7yslXvW0Bv5FlBKgaNKetE67T4Rp0AnOFn3srcPV_6HEUrU9FoQPeNw',1),(5,'2soaeng@gmail.com','$2a$10$pAEsLod0RPlw6OVr2tosfew1EBLqtA3t1PCZZADEBsGTFVnoyZ/rO','소앵이다','uploads/c4ce1c5a-9df3-4319-8110-48e6edafb748.png','FEMALE','1998-01-17','진짜 애니 조 아.. 흑발남캐가 채고 신이치로 채고 #도리','ROLE_USER','eyJhbGciOiJIUzUxMiJ9.eyJleHAiOjE2NjU0Njk1Nzl9.EJm-gi5eHmVHvtg93SuIlL1DRGzsMnYwVEAfQLHcOIN69GUvuLovJ_qEj6eqO3PnzCcIMYPYYPW5DlxWs6IOxw',1),(7,'nename8@naver.com','$2a$10$DzJ5HKLXTvTqDewxXT62MuV4paLHbg.HFpQF1ZlolMzLUOKMPRBGW','송땅이입니다만',NULL,'MALE','2022-09-27','안녕하세요!송땅이입니다만입니다.','ROLE_USER','eyJhbGciOiJIUzUxMiJ9.eyJleHAiOjE2NjUwNjU5NTR9.unA6WNbyyrnXXOHBDl8S-kymHLHCFrVm9u9bDrxIVRV1sNP3eND4gPVMyrrio6UF_cdoiyfMtG95RmCWLTPHbw',1),(18,'khlzzang@daum.net','$2a$10$eiMEHbZGl4n1B6POldrNT.oc3M16G6i1CszZ4QAu14eIs/TOdlnOq','화이팅입니다',NULL,'MALE','1997-11-04','안녕하세요!화이팅입니다입니다.','ROLE_USER','eyJhbGciOiJIUzUxMiJ9.eyJleHAiOjE2NjUxMjE0ODl9.aAJyf9SRQQkGLz3bDwxbLxnZVwiLnt_1KITkvn707mZOEYHz4tHXpL0IrE4_VvnuWhe7Wu8DyTMhiObzdP1ntw',0),(21,'keumdw95@naver.com','$2a$10$geFB9w2NgEiIkrqBrBZ0xeTHWc4m4v1qpwc6GkFAWBk3uzVBsh.Ae','신호동맘스터치',NULL,'MALE','1995-08-20','안녕하세요!신호동맘스터치입니다.','ROLE_USER','eyJhbGciOiJIUzUxMiJ9.eyJleHAiOjE2NjU0NTExMzJ9.kaIdDHoybbtMVL7Arz4ZAbrxsvQLAzbHDpDF2W5jB_sQj-lE1alhLtMWA5-jVOp0Fdl2Ql5sQl1pzmWfLiHJNg',1),(22,'asdasdf@naver.com','$2a$10$EEAcnBrtFJoEmv4tiVFo9ecPuOOK.hzw4TydWN62OWySHDoK1iqPG','누구게',NULL,'FEMALE','2022-10-12','안녕하세요!누구게입니다.','ROLE_USER',NULL,0),(24,'asdf@asdf.com','$2a$10$VIkSb45pdk1ORgUG/nXv6.JPCq.bALxhNcD60NEPMcv8TXtKVq6.C','염탐꾼',NULL,'MALE','2022-10-03','안녕하세요!염탐꾼입니다.','ROLE_USER','eyJhbGciOiJIUzUxMiJ9.eyJleHAiOjE2NjU0MjkzOTB9.8x0UogqGJaIZfYtCJbGw93xQLDqpDulIRCbRC3zoAnfNtDioSLL_LBfp6vbfJGvPBKLvX9vYDmXRS1Jq0FUddQ',0),(25,'asdf@naver.com','$2a$10$U244u8yxc..VX93rxmdQAuXNzUJtWo6JgrYoluIl.YF1uCDURL2YW','염탐꾼1',NULL,'MALE','2022-10-01','안녕하세요!염탐꾼1입니다.','ROLE_USER','eyJhbGciOiJIUzUxMiJ9.eyJleHAiOjE2NjU0Mjk0NzF9.n0X9Z7hwV5DyakdQG_80oFrT9qtWnLRN18Kd07dNhuCVtjG32EblPDLeNTncbPawqnKUoruFG--80MnOyMRmdg',0),(26,'tpdud285@naver.com','$2a$10$HDZGadfz8d/hpKec3Q/2BOKZLQlZREWZWYlvFm3Oitn47rJcMhs82','nickname',NULL,'MALE','birth','intro','ROLE_USER','eyJhbGciOiJIUzUxMiJ9.eyJleHAiOjE2NjU0Njk0Njh9.g7XGh3VNLsracdZeuUURQmgPCwkegcgRidkbOMAnk0wK7PXuOcne0EZ5hKZMOxDCh0Ud0DgnqNz_XJ0lvnqp-w',1);
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-04 19:22:50
